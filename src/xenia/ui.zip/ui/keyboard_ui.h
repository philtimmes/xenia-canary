/**
 *******************************************************************************
 * Xenia : Xbox 360 Emulator Research Project                                 *
 *******************************************************************************
 * Copyright 2022 Ben Vanik. All rights reserved.                             *
 * Released under the BSD license - see LICENSE in the root for more details. *
 *******************************************************************************
 */

#ifndef XENIA_UI_KEYBOARD_UI_H_
#define XENIA_UI_KEYBOARD_UI_H_

#include <memory>
#include <string>
#include <vector>

#include "xenia/ui/imgui_dialog.h"
#include "xenia/ui/imgui_drawer.h"

namespace xe {
namespace ui {

class KeyboardDialog : public ImGuiDialog {
 public:
  enum class InputType {
    kText,
    kNumber,
    kPassword,
  };

  // Callback for when the user confirms input
  using InputCallback = std::function<void(const std::string&)>;

  static KeyboardDialog* ShowKeyboard(ImGuiDrawer* imgui_drawer,
                                      const std::string& title,
                                      const std::string& initial_text,
                                      InputType type,
                                      InputCallback callback);

  ~KeyboardDialog();

  // Enable/disable controller navigation
  void SetControllerNavigationEnabled(bool enabled) {
    controller_navigation_enabled_ = enabled;
  }

 protected:
  KeyboardDialog(ImGuiDrawer* imgui_drawer, const std::string& title,
                 const std::string& initial_text, InputType type,
                 InputCallback callback);

  void OnDraw(ImGuiIO& io) override;
  void OnClose() override;

 private:
  void DrawKeyboardLayout();
  void DrawTextInput();
  void ProcessKeyInput(const std::string& key);

  std::string title_;
  std::string input_text_;
  InputType input_type_;
  InputCallback callback_;

  bool is_shifted_ = false;
  bool is_symbol_mode_ = false;
  bool is_caps_lock_ = false;
  
  // Controller support
  bool controller_navigation_enabled_ = true;
  
  // Navigation state
  bool has_opened_ = false;
};

}  // namespace ui
}  // namespace xe

#endif  // XENIA_UI_KEYBOARD_UI_H_
